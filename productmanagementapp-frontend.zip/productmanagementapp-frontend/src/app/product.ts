export class Product {
    constructor() { }
    public id: number;
    public title: string;
    public weight: number;
    public category: string;
    public brand: string;
    public price: number;
    
}